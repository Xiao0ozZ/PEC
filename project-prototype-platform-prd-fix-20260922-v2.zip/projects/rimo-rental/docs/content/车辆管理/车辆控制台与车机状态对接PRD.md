# 车辆控制台与车机状态对接 PRD

## 版本更新记录

| 版本 | 日期 | 更新内容 | 依据 |
| --- | --- | --- | --- |
| v1.4 | 2026-08-26 | 新增车辆速查表状态提醒、异常待关注统计、地图定位、更新时间及车机资料历史记录规则；分别明确汽车与微电车的实时车况异常标签；统一低电量、低压蓄电池术语。 | 车辆速查与车辆控制台联动口径确认。 |
| v1.3 | 2026-08-20 | 补充车辆控制台状态字段颜色映射；逾时未上报按离线灰色显示。 | 车辆控制台状态展示口径确认。 |
| v1.2 | 2026-08-20 | 原型内部字段统一使用 `gpsStatus`、`gprsStatus`；修正车机租约与多仓电池展示文案。 | 车辆控制台字段核对。 |
| v1.1 | 2026-08-20 | 修正时间口径：车机与平台时间均以 UTC 保存，页面按租户时区转换展示。 | 车机接口与平台时间处理口径确认。 |
| v1.0 | 2026-08-20 | 建立车辆控制台页面、车机即时资料、控车指令及字段映射规则。 | RITI《EDI 空中协议》V00.02，2026-08-19；`vehicle_console.html` |

## 1. 文档定位

本文定义营运端“车辆控制台、车辆速查表”的资料来源、页面字段、状态判断及控车指令处理规则。车机供应商接口字段为唯一外部字段依据；页面不得自行生成接口中不存在的车机状态字段。

对应原型：`02_原型和PRD/原型/营运端/vehicle_console.html`。

## 2. 范围

| 范围 | 说明 |
| --- | --- |
| 车辆类型 | `Vehicle` 汽车、`MicroEV` 微电车。`Motorcycle` 为供应商附件中的机车类型，不等同于微电车。 |
| 页面能力 | 车辆查询、最新车机状态、地图定位、更多状态、汽车远程控制、控制指令台账。 |
| 车辆速查表 | 面向车辆池快速筛选与异常关注；仅展示摘要和跳转车辆控制台入口，不重复展示控车明细。 |
| 微电车控制 | 本期仅展示状态，不开放远程控制指令。供应商支持的微电车租约指令保留后续对接，不在本页面开放。 |
| 不在本期展示 | 讯号强度、TBox 电源状态。供应商接口未提供对应字段，页面不得显示模拟值。 |

## 3. 接口与资料处理

### 3.1 车机资料接收

| 项目 | 规则 |
| --- | --- |
| 接收接口 | `POST /api/task/vehicle/immediateInfoUpload` |
| 调用方 | RITI 车机服务端；前端不得直接调用。 |
| 鉴权 | 供应商文件标示无 Authorization。RIMO 接收端仍须以来源网络、签章或双方确认的其他机制保护接口。 |
| 外层字段 | `DataType`、`ts`、`Data`。 |
| 允许资料类别 | `IduInfo`、`IduRealTimeInfo`、`IduLowVoltHiberInform`、`IduAccoffHiberInform`。 |
| 车机基础资料 | `IduInfo` 更新车机基础资料，不覆盖车辆即时状态。 |
| 即时 / 休眠资料 | 其余三类资料写入原始上报记录，并更新该 CID 的最新状态；缺少的字段不得覆盖既有有效值。 |
| 原始资料 | 每次上报完整保存原始 JSON、`DataType`、供应商 `ts` 与平台 `receivedAt`，时间统一以 UTC 保存，供问题追查。 |

### 3.2 时间字段

| 页面 / 内部字段 | 来源 | 规则 |
| --- | --- | --- |
| 平台接收时间 `receivedAt` | RIMO 后端自产 | RIMO 接收 `immediateInfoUpload` 并完成入库时写入，以 UTC 保存；页面按租户时区转换显示。不得使用供应商 `ts` 或前端刷新时间替代。 |
| 来源上报时间 `sourceTs` | 外层 `ts` | Unix Timestamp，毫秒。原样保存，用于排查上游上报延迟；本期不在主页面展示。 |
| 最新定位时间 `iduGpsTime` | `Data.iduGpsTime` | 供应商时间以 UTC 解析并保存；页面按租户时区转换显示。解析失败时显示 `NA`，不得以平台接收时间替代。 |

### 3.3 CID 与状态值标准化

| 项目 | 规则 |
| --- | --- |
| CID | 供应商样本中汽车使用 `iduId`，微电车使用 `IduId`。后端按 `Data.IduId ?? Data.iduId` 取值，标准化保存为 `iduId`。两者都不存在时拒绝更新最新状态并记录异常。 |
| 汽车防盗字段 | 先读取 `iduSecurityStatus`；若收到样本中的 `iduSecurityStatus `（尾随空白），作为兼容字段读取。标准化后统一为 `securityStatus`。 |
| 布尔状态 | `1`、`"1"`、`true` 统一为真；`0`、`"0"`、`false` 统一为假；`NA`、空值、缺失统一为未知。页面未知值显示 `NA`，不得显示为“否”或“关闭”。 |
| 定位与通讯字段 | `iduGPSStatus` 标准化为 `gpsStatus`；`iduGPRSStatus` 标准化为 `gprsStatus`。前后端均使用该字段名。 |
| 数值字段 | `NA`、空值、缺失不参与数值比较；其余值转换为 Decimal 后按字段单位展示。 |

### 3.4 车机新鲜度与离线状态

```text
资料逾时 = 当前 UTC 时间 - latest.receivedAt（UTC） > 10 分钟
页面车机在线 = Data.iduGPRSStatus = 1 AND 非资料逾时
```

| 条件 | 页面显示 | 控车处理 |
| --- | --- | --- |
| 非资料逾时且 GPRS=1 | `GPRS 在线` | 汽车允许发起控车指令。 |
| 非资料逾时且 GPRS=0 | `GPRS 离线` | 不发起控车指令。 |
| 资料逾时 | `逾时未上报` | 不发起控车指令。供应商指令回覆 `ErrorCode=004` 时同样显示为车机未上线。 |

页面每分钟重新判断一次资料逾时状态。新资料入库后立即重新计算。

### 3.5 状态颜色规则

除油量、电量与低电压外，状态字段只使用绿色和灰色；不得以红色、橙色区分一般开关或通讯状态。`NA`、空值、缺失一律显示灰色。

| 字段 / 页面状态 | 绿色 | 灰色 | 其他颜色 |
| --- | --- | --- | --- |
| 车辆行驶状态 | 车辆行驶中：使用全局主题主色。 | 车辆已静止。 | 无。 |
| `gpsStatus` GPS 定位 | 有效定位。 | 无效、`NA`。 | 无。 |
| `gprsStatus` GPRS 通讯 | 在线。 | 离线、逾时未上报、`NA`。 | 无。 |
| `rentalStatus` 车机租约 | 有租约。 | 无租约、`NA`。 | 无。 |
| `accStatus`、`powerOnStatus`、`motorStarted` | 发动车、引擎开启、马达已启动。 | 熄火、关闭、未启动、`NA`。 | 无。 |
| `securityStatus`、`doorLockStatus` | 防盗已解除、有车门解锁。 | 防盗已设防、全部上锁、`NA`。 | 无。 |
| `doorStatus`、`lightStatus`、`iButtonStatus` | 有车门开启、灯光开启、电子钥匙在位。 | 全部关闭、灯光关闭、钥匙不在位、`NA`。 | 无。 |
| 微电车 1 / 2 / 3 号仓 | 在仓已连接。 | 空仓未装配、`NA`。 | 无。 |
| 低压蓄电池低电压 `lowVoltage` | 正常。 | `NA`。 | 异常为红色。 |
| 剩余油量 / 总电量 `remainFuel`、`rsoc` | `>= 30%`。 | `NA`。 | `10%~29%` 为橙色；`< 10%` 为红色。 |

颜色仅用于识别当前状态，不改变控车权限、车辆营运状态或订单判断。

### 3.6 车辆速查表关注状态

#### 3.6.1 通用规则

1. 实时车况允许同时显示多个异常标签；同一标签只显示一次。
2. `NA`、空值或字段缺失不产生异常标签。
3. 资料逾时按离线处理，只显示“通讯异常”，不再叠加“定位异常”。
4. “异常待关注”按车辆去重；同一车辆存在多个异常标签时只统计 1 台。
5. 标签仅用于提示和筛选，不改变车辆启用状态、营运状态、订单状态或控车权限。
6. “低电压”显示在电压资料后方，不在下方标签组重复显示；其余标签按通讯、定位、低电量、安防异常的顺序展示。

#### 3.6.2 汽车 `Vehicle`

| 异常标签 | 内部字段 | 产生条件 | 额外前置条件 | 颜色 |
| --- | --- | --- | --- | --- |
| 通讯异常 | `gprsStatus`、`telemetryStale` | `gprsStatus=false OR telemetryStale=true` | 无 | 灰色 |
| 定位异常 | `gpsStatus` | `gpsStatus=false` | 车机在线且资料未逾时 | 灰色 |
| 低电量 | `remainFuel` | `remainFuel < 30` | `remainFuel` 必须为有效数值 | `10%~29%` 橙色；`<10%` 红色 |
| 低电压 | `lowVoltage` | `lowVoltage=true` | 无 | 红色 |
| 防盗未上锁 | `securityStatus` | `securityStatus=false` | 满足汽车安防判断前置条件 | 橙色 |
| 中控未上锁 | `doorLockStatus` | `doorLockStatus=false` | 满足汽车安防判断前置条件 | 橙色 |
| 车门未全关 | `doorStatus` | `doorStatus=true` | 满足汽车安防判断前置条件 | 橙色 |
| 电子钥匙未回位 | `iButtonStatus` | `iButtonStatus=false` | 满足汽车安防判断前置条件 | 橙色 |

汽车安防判断前置条件：`vehicleType=Vehicle AND gprsStatus=true AND telemetryStale=false AND status=IDLE AND 无订单 AND rentalStatus=false`。任一条件不满足时，不判断或显示 4 个安防异常标签。

#### 3.6.3 微电车 `MicroEV`

| 异常标签 | 内部字段 | 产生条件 | 额外前置条件 | 颜色 |
| --- | --- | --- | --- | --- |
| 通讯异常 | `gprsStatus`、`telemetryStale` | `gprsStatus=false OR telemetryStale=true` | 无 | 灰色 |
| 定位异常 | `gpsStatus` | `gpsStatus=false` | 车机在线且资料未逾时 | 灰色 |
| 低电量 | `rsoc` | `rsoc < 30` | `rsoc` 必须为有效数值 | `10%~29%` 橙色；`<10%` 红色 |
| 低电压 | `lowVoltage` | `lowVoltage=true` | 无 | 红色 |

微电车不显示防盗锁、中控锁、车门或电子钥匙异常标签。1 / 2 / 3 号仓电池字段本期仅展示车机回传值；未定义温度、电流、单仓电量或仓位识别异常阈值，不生成对应异常标签。

## 4. 页面字段

### 4.1 车辆检索与车辆摘要

以下字段来自 RIMO 车辆、组织与车机绑定资料，不来自 RITI 即时资料接口。

| 页面字段 | 来源字段 | 规则 |
| --- | --- | --- |
| 车行 / 门市 / 据点筛选 | 车辆所属车行、门市、据点 ID | 支持多选，筛选车辆范围。 |
| 车辆类型 | RIMO 车辆 `vehicleType` | 选项：全部、汽车 `Vehicle`、微电车 `MicroEV`。 |
| 关键字 | 车牌、VIN、车型、CID | 任一包含即命中。 |
| 车牌、车型、VIN | RIMO 车辆资料 | 仅作为车辆识别资料展示。 |
| CID | 车机绑定资料 `iduId` | 与车机上报资料标准化后的 CID 对应。 |
| 车辆行驶中 / 已静止 | RIMO 车辆营运状态或车机状态整合结果 | 不以单一 `iduSpeed` 直接替代既有车辆营运状态。 |
| 平台接收时间 | `receivedAt` | 见 3.2。 |
| 更新时间 | `receivedAt` | 显示在行驶动态中，表示平台最后接收该车机资料的时间。 |
| GPRS 标签 | `iduGPRSStatus` + `receivedAt` | 按 3.4 显示。 |
| 地图定位查看 | `iduGpsTime`、`latitude`、`longitude`、`address`、`gpsStatus`、`gprsStatus` | 行驶动态中的定位地址可点击查看地图弹窗；无有效经纬度时不显示入口。 |
| 关注状态筛选 | 速查表派生状态 | 支持通讯、定位、能量、电压及安防类异常。详见 3.6。 |
| 异常待关注统计 | 速查表派生状态 | 统计至少存在一项关注标签的车辆数，同一车辆只计 1 台。 |

顶部统计卡片可点击筛选：监控车辆池清除状态和关注状态条件；营运中带入`status=RENTED`；异常待关注勾选全部关注状态。再次点击当前卡片，清除其带入条件。关注状态支持多选，多个条件按“满足任一项”筛选。

### 4.6 车机资料历史记录

每次接收并完成字段标准化的车机资料，按车辆、`receivedAt`保存为不可覆盖的历史快照。速查表操作区提供“历史记录”，以近全屏弹窗分页查看。

历史记录不使用展开行。当次可取得资料以单行表完整展示，表格允许横向滚动：

| 车辆类型 | 历史字段 |
| --- | --- |
| 通用 | 平台接收时间、车机定位时间、GPS、GPRS、经纬度、总行驶里程、车速、剩余油量/总电量、低压蓄电池/直流侧电压、低电压、车机租约。 |
| 汽车 | ACC、引擎、防盗锁、中控锁、车门状态、灯光、电子钥匙状态、电子钥匙编号。 |
| 微电车 | 马达状态，以及 1 / 2 / 3 号仓的 SOC、电流、最低温、最高温、序号、韧体版本。 |

筛选条件：平台接收时间区间、经纬度/电子钥匙编号关键字、GPS、GPRS、能耗状态、低电压、车机租约、ACC/马达；汽车额外支持引擎、防盗锁、中控锁、车门状态、电子钥匙筛选。历史记录不得以当前最新状态覆盖。

### 4.2 车机基础资料 `IduInfo`

| 供应商实际字段 | 适用类型 | 页面字段 | 内部字段 | 规则 |
| --- | --- | --- | --- | --- |
| `IduId` / `iduId` | 汽车、微电车 | 设备 CID | `iduId` | 按 3.3 标准化。 |
| `iduType` | 汽车、微电车 | 安装车辆类别 | `iduType` | `Vehicle` 显示汽车；`MicroEV` 显示微电车。 |
| `iduBrandName` | 汽车、微电车 | 车机厂商 | `iduBrandName` | 原样展示。 |
| `iduModelName` | 汽车、微电车 | 车机型号 | `iduModelName` | 原样展示。 |
| `iduFW` | 汽车、微电车 | 车机韧体版本 | `iduFW` | 原样展示。 |
| `iduIMEI` | 汽车、微电车 | IMEI | `iduIMEI` | 原样展示。 |
| `iduICCID` | 汽车、微电车 | ICCID | `iduICCID` | 原样展示。 |

### 4.3 汽车即时状态 `IduRealTimeInfo` / 休眠通知

| 供应商实际字段 | 页面字段 | 内部字段 | 值与展示规则 | 页面位置 |
| --- | --- | --- | --- | --- |
| `IduId` / `iduId` | 设备 CID | `iduId` | 见 3.3。 | 更多状态 |
| `iduType` | 安装车辆类别 | `iduType` | 必须为 `Vehicle`。 | 更多状态 |
| `iduGpsTime` | 最新定位时间 / 车机时间 | `iduGpsTime` | UTC 保存，页面按租户时区显示。 | 地图卡片、地图弹窗、更多状态 |
| `iduGPSStatus` | GPS 定位状态 | `gpsStatus` | `1` 有效；`0` 无效；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduLatitude` | 纬度 | `latitude` | `NA` 时不定位。 | 地图弹窗、更多状态 |
| `iduLongitude` | 经度 | `longitude` | `NA` 时不定位。 | 地图弹窗、更多状态 |
| `iduGPRSStatus` | GPRS 连线状态 | `gprsStatus` | 按 3.4 显示在线、离线或逾时未上报。 | 摘要、状态矩阵、地图弹窗、更多状态 |
| `iduRentalStatus` | 车机租约状态 | `rentalStatus` | `1` 有租约；`0` 无租约；未知 `NA`。不得表述为订单进行中。 | 更多状态 |
| `iduACCStatus` | ACC 发动状态 | `accStatus` | `1` 发动车；`0` 熄火；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduPowerONStatus` | 引擎状态 | `powerOnStatus` | `1` 开启；`0` 关闭；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduSecurityStatus` | 防盗锁状态 | `securityStatus` | `1` 上锁；`0` 解锁；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduDoorStatus` | 车门物理状态 | `doorStatus` | `1` 有车门开启；`0` 全部关闭；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduDoorLockStatus` | 车门锁状态 | `doorLockStatus` | `1` 全部上锁；`0` 有车门解锁；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduLightStatus` | 灯光状态 | `lightStatus` | `1` 开启；`0` 关闭；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduIButtonStatus` | 车钥匙状态 | `iButtonStatus` | `1` 已挂回；`0` 未挂回；未知 `NA`。 | 更多状态 |
| `iduIButtonID` | iButton 编号 | `iButtonId` | 缺失显示 `NA`。 | 更多状态 |
| `iduVoltage` | 低压蓄电池电压 | `voltage` | 单位 V；`NA` 不做阈值判断。 | 更多状态 |
| `iduLowVoltage` | 低电压警示 | `lowVoltage` | `1` 异常；`0` 正常；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduDrivingBehaviorEvent` | 驾驶行为事件 | `drivingBehaviorEvent` | `N` 或 `NE` 表示未触发事件。 | 更多状态 |
| `iduSpeed` | 车速 | `speed` | 单位 km/hr。 | 更多状态 |
| `iduRPM` | 引擎转速 | `rpm` | `NA` 原样显示。 | 更多状态 |
| `iduMileage` | 总行驶里程 | `mileage` | 单位 km。 | 更多状态 |
| `iduRemainFuel` | 剩余油量 | `remainFuel` | 单位 %；仅在为数值时比较低油量阈值。 | 状态矩阵、更多状态 |
| `IduVIN` | VIN | `vin` | `NA` 原样显示；不覆盖 RIMO 车辆主档 VIN。 | 更多状态 |
| `iduBoxDeviceVersion` | 设备韧体版本 | `boxDeviceVersion` | 原样展示。 | 更多状态 |
| `iduWaitSecurityOnStatus` | 等待 ACC 关闭保全上锁 | `waitSecurityOnStatus` | `1` 等待中；`0` 否；未知 `NA`。 | 更多状态 |

### 4.4 微电车即时状态 `IduRealTimeInfo` / 休眠通知

| 供应商实际字段 | 页面字段 | 内部字段 | 值与展示规则 | 页面位置 |
| --- | --- | --- | --- | --- |
| `IduId` / `iduId` | 设备 CID | `iduId` | 见 3.3。 | 更多状态 |
| `iduType` | 安装车辆类别 | `iduType` | 必须为 `MicroEV`。 | 更多状态 |
| `iduGpsTime` | 最新定位时间 / 车机时间 | `iduGpsTime` | UTC 保存，页面按租户时区显示。 | 地图卡片、地图弹窗、更多状态 |
| `iduGPSStatus` | GPS 定位状态 | `gpsStatus` | `1` 有效；`0` 无效；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduLatitude` | 纬度 | `latitude` | `NA` 时不定位。 | 地图弹窗、更多状态 |
| `iduLongitude` | 经度 | `longitude` | `NA` 时不定位。 | 地图弹窗、更多状态 |
| `iduGPRSStatus` | GPRS 连线状态 | `gprsStatus` | 按 3.4 显示在线、离线或逾时未上报。 | 摘要、状态矩阵、地图弹窗、更多状态 |
| `iduRentalStatus` | 车机租约状态 | `rentalStatus` | `1` 有租约；`0` 无租约；未知 `NA`。不得表述为订单进行中。 | 更多状态 |
| `iduACCStatus` | 发动状态 | `accStatus` | `1` 发动车；`0` 熄火；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduStartOk` | 马达启动状态 | `startOk` | `1` 已启动；`0` 关闭；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduLowVoltage` | 低电压警示 | `lowVoltage` | `1` 异常；`0` 正常；未知 `NA`。 | 状态矩阵、更多状态 |
| `iduDCVoltage` | 直流侧电压 | `dcVoltage` | 单位 V。 | 更多状态 |
| `iduSpeed` | 车速 | `speed` | 单位 km/hr。 | 更多状态 |
| `iduMileage` | 总行驶里程 | `mileage` | 单位 km。 | 更多状态 |
| `iduCur` | 马达端电流 | `current` | 单位 A。 | 更多状态 |
| `iduRSOC` | 总电量 | `rsoc` | 单位 %；`NA` 不做阈值判断。 | 状态矩阵、更多状态 |
| `iduRDistance` | 预估续航里程 | `remainingDistance` | 单位 km。 | 状态矩阵、更多状态 |
| `iduMBA` | 1 号仓电池剩余电量 | `batterySlots.1.soc` | 供应商核心电池字段；单位 %。 | 更多状态 |
| `iduMBAA` | 1 号仓目前电流 | `batterySlots.1.current` | 供应商核心电池字段；单位 A。 | 更多状态 |
| `iduMBAT_Hi` | 1 号仓最高温度 | `batterySlots.1.tempHigh` | 供应商核心电池字段；单位 ℃。 | 更多状态 |
| `iduMBAT_Lo` | 1 号仓最低温度 | `batterySlots.1.tempLow` | 供应商核心电池字段；单位 ℃。 | 更多状态 |
| `iduMBAT_SN` | 1 号仓电池序号 | `batterySlots.1.serialNo` | 供应商核心电池字段。 | 更多状态 |
| `iduMBAT_FW` | 1 号仓电池韧体 | `batterySlots.1.firmware` | 供应商核心电池字段。 | 更多状态 |
| `iduRBA` | 2 号仓电池剩余电量 | `batterySlots.2.soc` | 供应商右侧电池字段；单位 %。 | 更多状态 |
| `iduRBAA` | 2 号仓目前电流 | `batterySlots.2.current` | 供应商右侧电池字段；单位 A。 | 更多状态 |
| `iduRBAT_Hi` | 2 号仓最高温度 | `batterySlots.2.tempHigh` | 供应商右侧电池字段；单位 ℃。 | 更多状态 |
| `iduRBAT_Lo` | 2 号仓最低温度 | `batterySlots.2.tempLow` | 供应商右侧电池字段；单位 ℃。 | 更多状态 |
| `iduRBAT_SN` | 2 号仓电池序号 | `batterySlots.2.serialNo` | 供应商右侧电池字段。 | 更多状态 |
| `iduRBAT_FW` | 2 号仓电池韧体 | `batterySlots.2.firmware` | 供应商右侧电池字段。 | 更多状态 |
| `iduLBA` | 3 号仓电池剩余电量 | `batterySlots.3.soc` | 供应商左侧电池字段；单位 %。 | 更多状态 |
| `iduLBAA` | 3 号仓目前电流 | `batterySlots.3.current` | 供应商左侧电池字段；单位 A。 | 更多状态 |
| `iduLBAT_Hi` | 3 号仓最高温度 | `batterySlots.3.tempHigh` | 供应商左侧电池字段；单位 ℃。 | 更多状态 |
| `iduLBAT_Lo` | 3 号仓最低温度 | `batterySlots.3.tempLow` | 供应商左侧电池字段；单位 ℃。 | 更多状态 |
| `iduLBAT_SN` | 3 号仓电池序号 | `batterySlots.3.serialNo` | 供应商左侧电池字段。 | 更多状态 |
| `iduLBAT_FW` | 3 号仓电池韧体 | `batterySlots.3.firmware` | 供应商字段说明写为右侧电池韧体版本，按字段名称暂列为左侧电池，待供应商确认。 | 更多状态 |

> 1、2、3 号仓是当前页面分组名称，分别映射供应商 MBA、RBA、LBA。页面标题为“多仓电池状态与实时参数”，温度合并显示为“温度范围”。电池字段有值显示“已识别电池”，缺失或 `NA` 显示“未识别电池”；不得表述为在仓、已连接、空仓或主供电。该映射不代表实体电池仓位定义，实体仓位名称以供应商书面确认结果为准。

### 4.5 地图地址

| 页面字段 | 来源 | 规则 |
| --- | --- | --- |
| 定位地址 | 地图服务逆地理编码 | 输入 `latitude`、`longitude`；地图服务无结果时显示经纬度，不得伪造地址。 |
| 地图定位点 | `latitude`、`longitude` | GPS 无效、经纬度为 `NA` 或无法解析时不显示定位点。 |

## 5. 汽车控车指令

### 5.1 调用规则

| 项目 | 规则 |
| --- | --- |
| 调用接口 | `POST /ControlVehicleAPI/api/IDU/ControlVehicle` |
| 鉴权 | 后端使用 `GetKey` 取得的 `CheckKey` 置于 `Authorization` Header。前端不得保存或传递 `CheckKey`。 |
| Request 字段 | `CmdId`、`IduId`、`MethodName`；有参数时加 `CmdParams`。 |
| HTTP 200 | 仅代表供应商已接受调用，不代表指令成功。 |
| 最终结果 | 由供应商回呼 `POST /api/task/controlVehicle/orderResult` 后确定。 |
| 重复限制 | 同一指令 5 秒内不可重复发送。页面在请求中与最终结果返回前禁用同一车辆同一指令。 |
| 指令前置 | 仅 `Vehicle` 且页面车机在线时允许下发；`MicroEV` 本期不显示控制按钮。 |

### 5.2 汽车页面指令映射

| 页面操作 | `MethodName` | `CmdParams` | 说明 |
| --- | --- | --- | --- |
| 中控上锁 | `LockCentral` | 无 | 汽车。 |
| 中控解锁 | `UnLockCentral` | 无 | 汽车。 |
| 防盗上锁 | `SecurityOn` | 无 | 汽车。 |
| 防盗解除 | `SecurityOff` | 无 | 汽车。 |
| 远程寻车（鸣笛 / 闪灯） | `FindVehicle` | 无 | 汽车。 |
| 手动刷新状态 | `UploadNow` | 无 | 仅汽车可向车机请求立即上报。页面只能在收到后续即时资料并写入 `receivedAt` 后更新，不得因指令 HTTP 200 直接刷新状态时间。 |

### 5.3 微电车保留指令

| `MethodName` | 供应商定义 | 本页面处理 |
| --- | --- | --- |
| `SetMotoRental` | 设置租约 | 不开放。 |
| `SetMotoRentalBLE` | 设置租约并含蓝牙密码 | 不开放。 |
| `SetMotoNoRental` | 解除租约 | 不开放。 |

供应商文件未定义微电车 `UploadNow` 或独立线上测试指令。本页面显示“微电车暂无控制功能”。

### 5.4 指令回呼与台账

供应商回呼字段：

| 供应商字段 | 内部字段 | 规则 |
| --- | --- | --- |
| `CmdId` | `commandId` | 发起指令时由 RIMO 生成，全流程唯一。 |
| `IduId` | `iduId` | 必须与发起指令的 CID 一致。 |
| `result` | `result` | `OK` 为成功；`NG` 为失败。 |
| `ErrorStep` | `errorStep` | 仅失败时保存。 |
| `ErrorCode` | `errorCode` | 仅失败时保存。 |

| 台账页面字段 | 来源 / 规则 |
| --- | --- |
| 下发时间 | RIMO 创建控车指令时间。 |
| 操作人 | 当前营运端账号或系统任务。 |
| 控制指令 | `MethodName` 转中文名称。 |
| 关联车牌 | RIMO 车辆资料。 |
| CID | `iduId`。 |
| 执行结果 | 初始为处理中；收到 `OK` 后成功；收到 `NG` 后失败。 |
| 备注说明 | 仅失败显示错误说明；成功记录不显示备注。 |

常用失败码：`004` 车机未上线、`005` 5 秒内重复指令、`006` CID 不在客户群组对应表、`007` 指令不存在、`008` 蓝牙密码长度错误、`009` 缺少必要参数、`012` 车机未回覆、`013` 已无租约仍解除、`015` OBD 指令执行失败。

## 6. 权限与操作限制

| 角色 / 权限 | 可见范围 | 操作范围 |
| --- | --- | --- |
| 具车辆控制台菜单权限的营运端账号 | 可查询授权组织范围内车辆与状态。 | 可查看地图、更多状态、台账。 |
| 具对应汽车控车操作权限的账号 | 同上。 | 可执行对应汽车指令。每次下发必须记录操作人、时间、CID、指令、结果与失败码。 |
| 无控车操作权限账号 | 同上。 | 控制按钮不显示或置灰，不得调用控车接口。 |

## 7. 验收标准

1. 微电车上报 `iduType=MicroEV` 时，车辆控制台显示“微电车”，不归入 `Motorcycle`。
2. 汽车 `iduId` 与微电车 `IduId` 均可关联到同一内部 `iduId` 字段。
3. `receivedAt`、`sourceTs`、`iduGpsTime` 均以 UTC 保存；页面展示时按当前租户时区转换。
4. 页面“平台接收时间”显示后端 `receivedAt`；供应商 `ts` 不得作为该字段来源；“最新定位”取 `iduGpsTime`。
5. `receivedAt` 超过 10 分钟时，即使 `iduGPRSStatus=1`，页面仍显示“逾时未上报”，汽车控车按钮不可执行。
6. 汽车与微电车所有状态字段均按本文件对应的供应商字段读取；`NA`、空值、缺失均显示 `NA`，不转换为正常或关闭。
7. 微电车更多状态以 1、2、3 号仓分组展示 MBA、RBA、LBA 的六项电池字段；字段不得遗漏。
8. 微电车远程指令区只显示“微电车暂无控制功能”，不显示测试线上或租约指令按钮。
9. 汽车控车收到 HTTP 200 后台账状态仍为处理中；仅收到 `result=OK` 才显示成功。
10. 控车成功记录备注为空；失败记录显示供应商错误码与对应说明。
11. 车辆速查表可按关注状态筛选；资料逾时显示为离线并计入通讯异常。
12. 同一车辆存在多项关注状态时，“异常待关注”仅统计 1 台。
13. 安防类异常只在空闲、在线、无订单且无车机租约的汽车上显示，展示具体异常名称。
14. 行驶动态中的有效定位地址可打开地图弹窗；弹窗显示定位时间、经纬度、地址及定位 / 通讯状态。
15. 行驶动态显示平台接收时间；历史记录以近全屏单行表展示完整快照，可按定义条件筛选并分页查看。
16. 汽车实时车况只生成 3.6.2 定义的异常标签；微电车只生成 3.6.3 定义的异常标签，不得跨车辆类型套用字段或自行增加未定义阈值。
