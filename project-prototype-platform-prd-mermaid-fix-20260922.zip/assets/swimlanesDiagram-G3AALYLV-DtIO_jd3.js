import{c as r,s as e}from"./flowDiagram-23GEKE2U-DfJ2VmZi.js";import{_ as a}from"./mermaid.core-BT36P1_y.js";import"./chunk-5VM5RSS4-BjOon_2F.js";import"./chunk-XXDRQBXY-BsXSfzE4.js";import"./chunk-VR4S4FIN-DNisgGnk.js";import"./chunk-32BRIVSS-CMo3tQhO.js";import"./MarkdownReader-CnKJE4qp.js";import"./react-runtime-CUbl_rHH.js";import"./index-CjHB4c6O.js";import"./data-runtime-DiihZ4CY.js";import"./channel-CYDluSHF.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
