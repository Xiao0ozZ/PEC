import{c as r,s as e}from"./flowDiagram-23GEKE2U-N2RoQySd.js";import{_ as a}from"./mermaid.core-BPBqAlW2.js";import"./chunk-5VM5RSS4-Uh-zwdDc.js";import"./chunk-XXDRQBXY-BFyXGHLG.js";import"./chunk-VR4S4FIN-Dz3dLKgx.js";import"./chunk-32BRIVSS-BPkW-QgU.js";import"./MarkdownReader-Bt0fcKSv.js";import"./react-runtime-CUbl_rHH.js";import"./index-mOp-e6HS.js";import"./data-runtime-DiihZ4CY.js";import"./channel-xzDWv-56.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
