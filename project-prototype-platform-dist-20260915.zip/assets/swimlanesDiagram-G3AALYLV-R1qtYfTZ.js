import{c as r,s as e}from"./flowDiagram-23GEKE2U-DK2LwXvN.js";import{_ as a}from"./mermaid.core-DgjTIo9r.js";import"./chunk-5VM5RSS4-7sUMkNNz.js";import"./chunk-XXDRQBXY-DsPCiqbO.js";import"./chunk-VR4S4FIN-B2wMwHvc.js";import"./chunk-32BRIVSS-ZsDsgUJP.js";import"./MarkdownReader-BYJqjFVD.js";import"./react-runtime-CUbl_rHH.js";import"./index-CrsJgbD8.js";import"./data-runtime-DiihZ4CY.js";import"./channel-BxK0-5xO.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
