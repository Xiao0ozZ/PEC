import{U as a,P as n}from"./mermaid.core-DnZiWr05.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
