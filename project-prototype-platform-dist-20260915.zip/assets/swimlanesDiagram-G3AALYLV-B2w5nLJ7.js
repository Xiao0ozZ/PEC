import{c as r,s as e}from"./flowDiagram-23GEKE2U-8ekD8MIE.js";import{_ as a}from"./mermaid.core-DnZiWr05.js";import"./chunk-5VM5RSS4-CEiiVj38.js";import"./chunk-XXDRQBXY-CXlWdvNm.js";import"./chunk-VR4S4FIN-s9NIPYsg.js";import"./chunk-32BRIVSS-BQv_wVqd.js";import"./MarkdownReader-Bnsm9Kv7.js";import"./react-runtime-CUbl_rHH.js";import"./index-GfJjVZd6.js";import"./data-runtime-DiihZ4CY.js";import"./channel-CyqZi7Sp.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
