import{c as r,s as e}from"./flowDiagram-23GEKE2U-BmVXXbxD.js";import{_ as a}from"./mermaid.core-DR-HMaIn.js";import"./chunk-5VM5RSS4-BtIcjZQ2.js";import"./chunk-XXDRQBXY-CWhQizhy.js";import"./chunk-VR4S4FIN-C6oHRp1L.js";import"./chunk-32BRIVSS-Bb-rtXcx.js";import"./MarkdownReader-_TElbZBu.js";import"./react-runtime-CUbl_rHH.js";import"./index-CFlRzoWI.js";import"./data-runtime-DiihZ4CY.js";import"./channel-DhwVJWdu.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
