import{U as a,P as n}from"./mermaid.core-DMbAXDGc.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
