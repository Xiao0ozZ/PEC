import{c as r,s as e}from"./flowDiagram-23GEKE2U-ugKMRuvh.js";import{_ as a}from"./mermaid.core-DMbAXDGc.js";import"./chunk-5VM5RSS4-zDfAQtr4.js";import"./chunk-XXDRQBXY-C5ujYxBi.js";import"./chunk-VR4S4FIN-DoN5a1tR.js";import"./chunk-32BRIVSS-DeGyLL-6.js";import"./MarkdownReader-CVqoPpK2.js";import"./react-runtime-CUbl_rHH.js";import"./index-BaHVkjWN.js";import"./data-runtime-DiihZ4CY.js";import"./channel-BQm9QWLX.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
